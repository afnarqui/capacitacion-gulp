var saludo;
saludo = function(nombre){
	return ("hola " + nombre);
};
