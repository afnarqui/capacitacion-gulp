var alumnos = {
	nombre: "julio cesar",
	apellido: "naranjo",
	direccion: "calle de rodal",
	telefono: "8907098"
};