var suma = function (a , b){
   
	//hola
   return ( a + b );
};

