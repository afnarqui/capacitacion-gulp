var restar;
restar = function(a,b){
	return (a-b);
};
